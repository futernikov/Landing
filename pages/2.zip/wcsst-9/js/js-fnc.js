$(function(){
	$('#featured-content h2').css ('text-shadow','#c2c2c2 0 2px 3px');
})